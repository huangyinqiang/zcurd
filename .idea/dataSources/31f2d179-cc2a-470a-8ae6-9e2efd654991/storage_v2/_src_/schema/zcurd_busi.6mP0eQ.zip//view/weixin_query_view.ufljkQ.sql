create view weixin_query_view as
  select
    `zcurd_busi`.`tuser`.`nickName`                   AS `nickName`,
    `zcurd_busi`.`tuser`.`headimgurl`                 AS `headimgurl`,
    (`zcurd_busi`.`tuser`.`walletAccount` / 100)      AS `walletAccount`,
    (`zcurd_busi`.`charge_money_info`.`money` / 100)  AS `money`,
    (`zcurd_busi`.`charge_money_info`.`amount` / 100) AS `amount`,
    `zcurd_busi`.`charge_money_info`.`createTime`     AS `createTime`,
    `zcurd_busi`.`charge_money_info`.`chargeType`     AS `chargeType`,
    `zcurd_busi`.`charge_money_info`.`id`             AS `id`,
    `zcurd_busi`.`qr_match_device`.`area`             AS `area`,
    `zcurd_busi`.`qr_match_device`.`gid`              AS `gid`
  from ((`zcurd_busi`.`tuser`
    join `zcurd_busi`.`charge_money_info`
      on ((convert(`zcurd_busi`.`charge_money_info`.`openId` using utf8mb4) = `zcurd_busi`.`tuser`.`openId`))) join
    `zcurd_busi`.`qr_match_device`
      on ((`zcurd_busi`.`charge_money_info`.`deviceId` = `zcurd_busi`.`qr_match_device`.`match_num`)));

