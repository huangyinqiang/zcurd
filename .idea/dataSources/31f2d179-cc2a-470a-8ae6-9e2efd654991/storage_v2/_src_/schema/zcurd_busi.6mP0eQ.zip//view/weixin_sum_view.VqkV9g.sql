create view weixin_sum_view as
  select
    (sum(`zcurd_busi`.`charge_money_info`.`money`) / 100)  AS `money`,
    (sum(`zcurd_busi`.`charge_money_info`.`amount`) / 100) AS `amount`,
    (sum(`zcurd_busi`.`tuser`.`walletAccount`) / 100)      AS `walletaccount`
  from (`zcurd_busi`.`charge_money_info`
    join `zcurd_busi`.`tuser`
      on ((convert(`zcurd_busi`.`charge_money_info`.`openId` using utf8mb4) = `zcurd_busi`.`tuser`.`openId`)));

