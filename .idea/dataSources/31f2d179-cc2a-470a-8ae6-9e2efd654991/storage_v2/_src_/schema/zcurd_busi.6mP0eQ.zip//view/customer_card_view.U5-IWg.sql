create view customer_card_view as
  select
    `zcurd_busi`.`cardlog`.`cardCode`       AS `cardCode`,
    `zcurd_busi`.`cardlog`.`phyicalId`      AS `phyicalId`,
    `zcurd_busi`.`cardlog`.`balance`        AS `balance`,
    `zcurd_busi`.`cardlog`.`joinDate`       AS `joinDate`,
    `zcurd_busi`.`customer`.`cardnum`       AS `cardnum`,
    `zcurd_busi`.`customer`.`phone`         AS `phone`,
    `zcurd_busi`.`customer`.`name`          AS `name`,
    `zcurd_busi`.`qr_match_device`.`remark` AS `remark`,
    `zcurd_busi`.`qr_match_device`.`gid`    AS `gid`,
    `zcurd_busi`.`cardlog`.`id`             AS `id`
  from ((`zcurd_busi`.`cardlog`
    left join `zcurd_busi`.`customer` on ((`zcurd_busi`.`cardlog`.`cardCode` = `zcurd_busi`.`customer`.`cardnum`))) join
    `zcurd_busi`.`qr_match_device`
      on ((`zcurd_busi`.`cardlog`.`deviceId` = `zcurd_busi`.`qr_match_device`.`match_num`)))
  order by `zcurd_busi`.`cardlog`.`joinDate` desc;

