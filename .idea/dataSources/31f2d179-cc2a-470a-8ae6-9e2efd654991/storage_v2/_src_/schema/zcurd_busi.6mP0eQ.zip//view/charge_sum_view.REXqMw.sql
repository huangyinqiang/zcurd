create view charge_sum_view as
  select
    `zcurd_busi`.`charge_battery_info`.`operType`            AS `operType`,
    (sum(`zcurd_busi`.`charge_battery_info`.`charge`) / 100) AS `charge`
  from (`zcurd_busi`.`charge_battery_info`
    left join `zcurd_busi`.`qr_match_device`
      on ((`zcurd_busi`.`charge_battery_info`.`deviceId` = `zcurd_busi`.`qr_match_device`.`match_num`)))
  group by `zcurd_busi`.`charge_battery_info`.`operType`;

