create view charge_info_view as
  select
    `zcurd_busi`.`charge_battery_info`.`id`                    AS `id`,
    `zcurd_busi`.`tuser`.`nickName`                            AS `nickName`,
    `zcurd_busi`.`tuser`.`headimgurl`                          AS `headimgurl`,
    `zcurd_busi`.`qr_match_device`.`area`                      AS `area`,
    `zcurd_busi`.`qr_match_device`.`remark`                    AS `remark`,
    `zcurd_busi`.`qr_match_device`.`qr_num`                    AS `qr_num`,
    `zcurd_busi`.`charge_battery_info`.`devicePort`            AS `devicePort`,
    `zcurd_busi`.`charge_battery_info`.`startTime`             AS `startTime`,
    `zcurd_busi`.`charge_battery_info`.`endTime`               AS `endTime`,
    `zcurd_busi`.`charge_battery_info`.`operType`              AS `operType`,
    `zcurd_busi`.`charge_battery_info`.`status`                AS `status`,
    (`zcurd_busi`.`charge_battery_info`.`charge` / 100)        AS `charge`,
    `zcurd_busi`.`charge_battery_info`.`chargeTime`            AS `chargeTime`,
    `zcurd_busi`.`charge_battery_info`.`createDate`            AS `createDate`,
    `zcurd_busi`.`qr_match_device`.`gid`                       AS `gid`,
    (`zcurd_busi`.`charge_battery_info`.`walletAccount` / 100) AS `walletAccount`,
    `zcurd_busi`.`charge_battery_info`.`feeStatus`             AS `feeStatus`,
    `zcurd_busi`.`charge_battery_info`.`realChargeTime`        AS `realChargeTime`
  from ((`zcurd_busi`.`charge_battery_info`
    join `zcurd_busi`.`qr_match_device`
      on ((`zcurd_busi`.`charge_battery_info`.`deviceId` = `zcurd_busi`.`qr_match_device`.`match_num`))) join
    `zcurd_busi`.`tuser`
      on ((convert(`zcurd_busi`.`charge_battery_info`.`openId` using utf8mb4) = `zcurd_busi`.`tuser`.`openId`)));

